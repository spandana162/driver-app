export default{
    PRIMARY: '#FADA5E',
    GRAY: 'c0c0c0'
}